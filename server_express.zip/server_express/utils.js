export function afficherBienvenue() {
console.log("Bienvenue sur MiniCoin !");
}