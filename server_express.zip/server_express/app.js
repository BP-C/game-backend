import express, { application } from "express";
const app = express();
const PORT = 3000;
const annonces = [
{
id: 1,
titre: "Vélo VTT",
description: "Très bon état",
prix: 250,
categorie: "Sport"
},
{
id: 2,
titre: "Ordinateur portable",
description: "PC 15 pouces",
prix: 450,
categorie: "Informatique"
}
];
app.get("/", (req, res) => {
res.send("Bienvenue sur MiniCoin !");
});

app.get("/api/annonces", (req, res) => {
res.json(annonces);
});

1
app.listen(PORT, () => {
console.log(`Serveur démarré sur http://localhost:${PORT}
`);
});

app.get("/api/annonces/:id", (req, res) => {
const id = Number(req.params.id);
const annonce = annonces.find((element) => {
return element.id === id;
});
if (!annonce) {
return res.status(404).json({
message: "Annonce introuvable"
});
}
res.json(annonce);
});

app.use(express.json());

app.post("/api/annonces", (req, res) => {
const nouvelleAnnonce = {
id: Math.max(0, ...annonces.map(a => a.id)) + 1,
...req.body
};
annonces.push(nouvelleAnnonce);
res.status(201).json(nouvelleAnnonce);
});

app.get("/api/status", (req, res) => {
    res.json({
        application: "MiniCoin",
        version: "1.0",
        statut: "en ligne"
    })
})